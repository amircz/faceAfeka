//config.js
/** TWITTER APP CONFIGURATION
 * consumer_key
 * consumer_secret
 * access_token
 * access_token_secret
 */
module.exports = {  
  consumer_key: 'HwuTWcDYHeLQxLneleljkUMdn',  
  consumer_secret: 'JEoZ7fAUKVsmq6SzSoM7k5oU4XPkE78OKQ2OKkt3TiEYDboNiU',
  access_token: '868403337573617666-P86jYEirBH2jXsCVKWVd03ZuVd6wXvS',  
  access_token_secret: 'rXOFkde7ydvqa7RhGi0NqOs3eOuNk4XtbvIRadCUlFJJl'
}